__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_local_disk_policy(handle, parent_dn, ld_policy_dict):

    # Args:
    # handle (UcsHandle)
    # name (string): Name of the local disk policy.
    # mode (string): no-local-storage, raid-mirrored, any-configuration...
    # flex_state (string): "enable" or "disable"
    # flex_raid (string): "enable" or "disable"
    # protect_config (string): "yes" or "no"
    # descr (string): Basic description.
    # parent_dn (string): Parent of Org.

    from ucsmsdk.mometa.storage.StorageLocalDiskConfigPolicy import \
        StorageLocalDiskConfigPolicy

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("Org {} does not exist" .format(parent_dn))

    mo = StorageLocalDiskConfigPolicy(
        parent_mo_or_dn=obj,
        protect_config=ld_policy_dict['protect'],
        name=ld_policy_dict['name'],
        descr=ld_policy_dict['descr'],
        flex_flash_raid_reporting_state=ld_policy_dict['flex_raid'],
        flex_flash_state=ld_policy_dict['flex_state'],
        mode=ld_policy_dict['mode'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print("Created Local Disk Policy: {} in {}" .format(ld_policy_dict['name'], parent_dn))

    return ld_policy_dict['name']