__author__ = 'jamakar'

def create_boot_policy(handle, parent_dn, boot_policy_dict):

    from ucsmsdk.mometa.lsboot.LsbootPolicy import LsbootPolicy
    from ucsmsdk.mometa.lsboot.LsbootVirtualMedia import LsbootVirtualMedia
    from ucsmsdk.mometa.lsboot.LsbootStorage import LsbootStorage
    from ucsmsdk.mometa.lsboot.LsbootLocalStorage import LsbootLocalStorage
    from ucsmsdk.mometa.lsboot.LsbootDefaultLocalImage import LsbootDefaultLocalImage
    from ucsmsdk.mometa.lsboot.LsbootUsbFlashStorageImage import LsbootUsbFlashStorageImage
    from ucsmsdk.mometa.lsboot.LsbootSan import LsbootSan
    from ucsmsdk.mometa.lsboot.LsbootSanCatSanImage import LsbootSanCatSanImage
    from ucsmsdk.mometa.lsboot.LsbootSanCatSanImagePath import LsbootSanCatSanImagePath
    from ucsmsdk.mometa.lsboot.LsbootLan import LsbootLan
    from ucsmsdk.mometa.lsboot.LsbootLanImagePath import LsbootLanImagePath

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("Org {} does not exist" .format(parent_dn))

    mo = LsbootPolicy(parent_mo_or_dn=obj,
                      name=boot_policy_dict['name'],
                      descr=boot_policy_dict['descr'],
                      reboot_on_update=boot_policy_dict['reboot_on_update'],
                      policy_owner=boot_policy_dict['policy_owner'],
                      enforce_vnic_name=boot_policy_dict['enforce_vnic_name'],
                      boot_mode=boot_policy_dict['boot_mode'])

    # Select the boot media
    for type in boot_policy_dict['media']:
        media = boot_policy_dict['media'][type]
        if type == "CD/DVD":
            # CD/DVD remote ISO
            mo_1 = LsbootVirtualMedia(parent_mo_or_dn=mo,
                                      access="read-only",
                                      lun_id="0",
                                      mapping_name="",
                                      order=media['order'])
        elif type == "HDD/SSD":
            # Local disk
            mo_2 = LsbootStorage(parent_mo_or_dn=mo, order=media['order'])
            mo_2_1 = LsbootLocalStorage(parent_mo_or_dn=mo_2, )
            mo_2_1_1 = LsbootDefaultLocalImage(parent_mo_or_dn=mo_2_1, order=media['order'])
        elif type == "FlexFlash":
            # FlexFlash (SD Card)
            mo_3 = LsbootStorage(parent_mo_or_dn=mo, order=media['order'])
            mo_3_1 = LsbootLocalStorage(parent_mo_or_dn=mo_3, )
            mo_3_1_1 = LsbootUsbFlashStorageImage(parent_mo_or_dn=mo_3_1, order=media['order'])
        elif type == "FC_SAN":
            # FC SAN boot
            mo_4 = LsbootSan(parent_mo_or_dn=mo, order=media['order'])
            mo_4_1 = LsbootSanCatSanImage(parent_mo_or_dn=mo_4,
                                          type="primary",
                                          vnic_name=media['primary_adapter'])
            mo_4_1_1 = LsbootSanCatSanImagePath(parent_mo_or_dn=mo_4_1,
                                                wwn=media['primary_wwn'],
                                                type="primary",
                                                lun=media['lun_id'])
            mo_4_1_2 = LsbootSanCatSanImagePath(parent_mo_or_dn=mo_4_1,
                                                wwn=media['primary_wwn_secondary'],
                                                type="secondary",
                                                lun=media['lun_id'])
            mo_4_2 = LsbootSanCatSanImage(parent_mo_or_dn=mo_4,
                                          type="secondary",
                                          vnic_name=media['secondary_adapter'])
            mo_4_2_1 = LsbootSanCatSanImagePath(parent_mo_or_dn=mo_4_2,
                                                wwn=media['secondary_wwn'],
                                                type="primary",
                                                lun=media['lun_id'])
            mo_4_2_2 = LsbootSanCatSanImagePath(parent_mo_or_dn=mo_4_2,
                                                wwn=media['secondary_wwn_secondary'],
                                                type="secondary",
                                                lun=media['lun_id'])
        elif type == "Net":
            # Network boot
            mo_5 = LsbootLan(parent_mo_or_dn=mo, prot="pxe", order=media['order'])
            mo_5_1 = LsbootLanImagePath(parent_mo_or_dn=mo_5,
                                        prov_srv_policy_name="",
                                        img_sec_policy_name="",
                                        vnic_name=media['primary_adapter'],
                                        i_scsi_vnic_name="",
                                        boot_ip_policy_name="",
                                        img_policy_name="",
                                        type="primary")
            mo_5_2 = LsbootLanImagePath(parent_mo_or_dn=mo_5,
                                        prov_srv_policy_name="",
                                        img_sec_policy_name="",
                                        vnic_name=media['secondary_adapter'],
                                        i_scsi_vnic_name="",
                                        boot_ip_policy_name="",
                                        img_policy_name="",
                                        type="secondary")
        else:
            raise ValueError("Media {} does not exist" .format(type))

    handle.add_mo(mo)
    handle.commit()

    print("Created Boot policy: {} in {}" .format(boot_policy_dict['name'], parent_dn))

    return boot_policy_dict['name']