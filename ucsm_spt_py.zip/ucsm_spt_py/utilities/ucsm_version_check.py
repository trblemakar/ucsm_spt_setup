__author__ = 'jamakar'

def ucsm_version_check(handle):

    ucsm = handle.version
    ucsm_version = ucsm.version

    if ucsm_version[0] == "3" and (ucsm_version[2] == "1" or ucsm_version[2] == "2"):
        print("Running UCSM version: {}".format(ucsm_version))
        #print("true")
    else:
        print("*** {} is an unsupported version ***".format(ucsm_version))
        #print("false")