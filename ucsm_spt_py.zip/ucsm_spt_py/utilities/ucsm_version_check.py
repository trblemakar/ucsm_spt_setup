__author__ = 'jamakar'

def ucsm_version_check(handle):

    ucsm = handle.version
    ucsm_version = ucsm.version

    if ucsm_version[0:3] != "3.1":
        print("*** {} is an unsupported version ***" .format(ucsm_version))
        exit()
    else:
        print("Running UCSM version: {}".format(ucsm_version))