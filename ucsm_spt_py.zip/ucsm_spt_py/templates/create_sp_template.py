__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_sp_template(handle, parent_dn, sp_temp_dict):

    from ucsmsdk.mometa.ls.LsServer import LsServer
    from ucsmsdk.mometa.vnic.VnicConnDef import VnicConnDef
    from ucsmsdk.mometa.ls.LsPower import LsPower

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("MO {} is not available" .format(parent_dn))

    mo = LsServer(parent_mo_or_dn=obj,
                  vmedia_policy_name=sp_temp_dict['vmedia_policy_name'],
                  ext_ip_state=sp_temp_dict['ext_ip_state'],
                  bios_profile_name=sp_temp_dict['bios_profile_name'],
                  mgmt_fw_policy_name=sp_temp_dict['mgmt_fw_policy_name'],
                  agent_policy_name=sp_temp_dict['agent_policy_name'],
                  mgmt_access_policy_name=sp_temp_dict['mgmt_access_policy_name'],
                  dynamic_con_policy_name=sp_temp_dict['dynamic_con_policy_name'],
                  kvm_mgmt_policy_name=sp_temp_dict['kvm_mgmt_policy_name'],
                  sol_policy_name=sp_temp_dict['sol_policy_name'],
                  uuid=sp_temp_dict['uuid'],
                  descr=sp_temp_dict['descr'],
                  stats_policy_name=sp_temp_dict['stats_policy_name'],
                  policy_owner=sp_temp_dict['policy_owner'],
                  ext_ip_pool_name=sp_temp_dict['ext_ip_pool_name'],
                  boot_policy_name=sp_temp_dict['boot_policy_name'],
                  usr_lbl=sp_temp_dict['usr_lbl'],
                  host_fw_policy_name=sp_temp_dict['host_fw_policy_name'],
                  vcon_profile_name=sp_temp_dict['vcon_profile_name'],
                  ident_pool_name=sp_temp_dict['ident_pool_name'],
                  src_templ_name=sp_temp_dict['src_templ_name'],
                  type=sp_temp_dict['type'],
                  local_disk_policy_name=sp_temp_dict['local_disk_policy_name'],
                  scrub_policy_name=sp_temp_dict['scrub_policy_name'],
                  power_policy_name=sp_temp_dict['power_policy_name'],
                  maint_policy_name=sp_temp_dict['maint_policy_name'],
                  name=sp_temp_dict['name'],
                  power_sync_policy_name=sp_temp_dict['power_sync_policy_name'],
                  resolve_remote=sp_temp_dict['resolve_remote'])

    mo_1 = VnicConnDef(parent_mo_or_dn=mo,
                       san_conn_policy_name=sp_temp_dict['san_conn_policy_name'],
                       lan_conn_policy_name=sp_temp_dict['lan_conn_policy_name'])

    mo_2 = LsPower(parent_mo_or_dn=mo,
                    state=sp_temp_dict['server_power_state'])

    handle.add_mo(mo)
    handle.commit()

    print("Created Service Profile template: {} in {}" .format(sp_temp_dict['name'], parent_dn))