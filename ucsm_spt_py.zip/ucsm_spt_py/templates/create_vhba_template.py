__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_vhba_template(handle, parent_dn, name, vhba_dict):

    # Args:
    # handle (UcsHandle)
    # name (String): vNIC Template name
    # descr (String): description
    # stats_policy_name (String):
    # switch_id (String):
    # pin_to_group_name (String):
    # policy_owner (String):
    # peer_redundancy_templ_name (String):
    # templ_type (String):
    # qos_policy_name (String):
    # ident_pool_name (String):
    # max_data_field_size (String):

    from ucsmsdk.mometa.vnic.VnicSanConnTempl import VnicSanConnTempl
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("MO {} is not available" .format(parent_dn))

    mo = VnicSanConnTempl(parent_mo_or_dn=obj,
                          redundancy_pair_type=vhba_dict['redundancy_pair_type'],
                          name=name,
                          descr=vhba_dict['descr'],
                          stats_policy_name=vhba_dict['stats_policy_name'],
                          switch_id=vhba_dict['fabric_id'],
                          pin_to_group_name=vhba_dict['pin_to_group_name'],
                          policy_owner=vhba_dict['policy_owner'],
                          peer_redundancy_templ_name=vhba_dict['peer_redundancy_templ_name'],
                          templ_type=vhba_dict['templ_type'],
                          qos_policy_name=vhba_dict['qos_policy_name'],
                          ident_pool_name=vhba_dict['wwpn_pool'],
                          max_data_field_size="2048")

    mo_1 = VnicFcIf(parent_mo_or_dn=mo, name=vhba_dict['vsan_name'])

    handle.add_mo(mo)
    handle.commit()

    print("Created vHBA template {} with wwpn pool {} in {}" .format(name, vhba_dict['wwpn_pool'], parent_dn))