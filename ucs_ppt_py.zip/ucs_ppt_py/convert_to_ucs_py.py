__author__ = 'jamakar'

from ucsmsdk.utils.ucsguilaunch import ucs_gui_launch
from ucsmsdk.ucshandle import UcsHandle

ucsm_ip = '192.168.190.216'
user = 'ucspe'
password = 'ucspe'

# Login to the server
handle = UcsHandle(ucsm_ip, user, password)
handle.login()

# launch the UCSM GUI
ucs_gui_launch(handle)

# Print the equivalent script to console
from ucsmsdk.utils.converttopython import convert_to_ucs_python
convert_to_ucs_python()