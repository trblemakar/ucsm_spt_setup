__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_wwnn_pool(handle, name, assignment_order,
                    r_from, to, descr="", parent_dn="org-root"):

# needs work, does not create node name pool

    # Args:
    # handle (UcsHandle)
    # name (String) :
    # assignment_order (String) : ["default", "sequential"]
    # r_from (String) : Beginning WWNN Address
    # to (String) : Ending WWNN Address
    # descr (String) :
    # parent_dn (String) : "org-root"

    from ucsmsdk.mometa.fcpool.FcpoolInitiators import FcpoolInitiators
    from ucsmsdk.mometa.fcpool.FcpoolBlock import FcpoolBlock

    obj = handle.query_dn(parent_dn)
    if obj:
        mo = FcpoolInitiators(parent_mo_or_dn=obj,
                         policy_owner="local",
                         descr=descr,
                         assignment_order=assignment_order,
                         name=name,
                         purpose="node-wwn-assignment")
        FcpoolBlock(parent_mo_or_dn=mo,
                     to=to,
                     r_from=r_from)

        handle.add_mo(mo, modify_present=True)
        handle.commit()

        print "Created WWNN Pool: " + name + " in " + parent_dn

        return mo
    else:
        raise ValueError("org '%s' is not available" % parent_dn)