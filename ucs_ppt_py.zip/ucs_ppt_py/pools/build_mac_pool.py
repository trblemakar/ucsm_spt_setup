__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_mac_pool(handle, parent_dn, pool_dict):

    # Args:
    # handle (UcsHandle)
    # name (String) :
    # assignment_order (String) : ["default", "sequential"]
    # r_from (String) : Beginning MAC Address
    # to (String) : Ending MAC Address
    # descr (String) :
    # parent_dn (String) : "org-root"

    from ucsmsdk.mometa.macpool.MacpoolPool import MacpoolPool
    from ucsmsdk.mometa.macpool.MacpoolBlock import MacpoolBlock

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' is not available" % parent_dn)

    mo = MacpoolPool(parent_mo_or_dn=obj,
                     policy_owner="local",
                     descr=pool_dict['descr'],
                     assignment_order=pool_dict['assignment_order'],
                     name=pool_dict['name'])

    MacpoolBlock(parent_mo_or_dn=mo,
                 to=pool_dict['to'],
                 r_from=pool_dict['from'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created MAC Pool: " + pool_dict['name'] + " in " + parent_dn

    return mo