__author__ = 'jamakar'

def create_maintenance_policy(handle, parent_dn, maintenance_policy_dict):

    # Args:
    # handle (UcsHandle)
    # name (string): Name of the maintenance policy.
    # uptime_disr (string): "immediate" or "timer-automatic" or "user-ack"
    # descr (string): Basic description.
    # parent_dn (string): Parent of Org.

    from ucsmsdk.mometa.lsmaint.LsmaintMaintPolicy import LsmaintMaintPolicy

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % parent_dn)

    mo = LsmaintMaintPolicy(parent_mo_or_dn=obj,
                            name=maintenance_policy_dict['name'],
                            uptime_disr=maintenance_policy_dict['uptime_disr'],
                            descr=maintenance_policy_dict['descr'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created Maintenance Policy: " + maintenance_policy_dict['name'] + " in " + parent_dn

    return maintenance_policy_dict['name']