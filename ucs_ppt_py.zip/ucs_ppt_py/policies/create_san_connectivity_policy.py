__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_san_connectivity_policy(handle, parent_dn, san_conn_details_dict):

    # Args:
    # handle (UcsHandle)
    # name (string): Name of the SAN connectivity policy
    # descr (string): Basic description.
    # parent_dn (string): Parent of Org.
    # wwnn_pool (string): wwnn pool

    from ucsmsdk.mometa.vnic.VnicSanConnPolicy import VnicSanConnPolicy
    from ucsmsdk.mometa.vnic.VnicFc import VnicFc
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf
    from ucsmsdk.mometa.vnic.VnicFcNode import VnicFcNode

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % parent_dn)

    mo = VnicSanConnPolicy(parent_mo_or_dn=obj,
                           policy_owner=san_conn_details_dict['policy_owner'],
                           name=san_conn_details_dict['name'],
                           descr=san_conn_details_dict['descr'])

    mo_2 = VnicFcNode(parent_mo_or_dn=mo,
                      ident_pool_name=san_conn_details_dict['wwnn_pool'],
                      addr="pool-derived")

    handle.add_mo(mo)
    handle.commit()

    print "Created SAN Connectivity Policy " + san_conn_details_dict['name'] + " in " + parent_dn

    return san_conn_details_dict['name']