__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_san_connectivity_policy(handle, san_conn_details):

    from ucsmsdk.mometa.vnic.VnicSanConnPolicy import VnicSanConnPolicy
    from ucsmsdk.mometa.vnic.VnicFc import VnicFc
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf
    from ucsmsdk.mometa.vnic.VnicFcNode import VnicFcNode

    parent_dn = san_conn_details['parent_dn']
    obj = handle.query_dn(parent_dn)

    mo = VnicSanConnPolicy(parent_mo_or_dn=obj, policy_owner="local", name=san_conn_details['name'], descr=san_conn_details['descr'])

    mo_2 = VnicFcNode(parent_mo_or_dn=mo, ident_pool_name=san_conn_details['wwnn_pool'], addr="pool-derived")

    handle.add_mo(mo)
    handle.commit()

    print "Created SAN Connectivity Policy " + san_conn_details['name'] + " in " + san_conn_details['parent_dn']