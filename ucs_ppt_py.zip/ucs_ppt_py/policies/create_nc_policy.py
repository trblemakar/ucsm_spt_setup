__author__ = 'jamakar'

def create_nc_policy(handle, parent_dn, nc_policy):

    # Args:
    # handle(UcsHandle)
    # name(String): Network Control Policy Name
    # cdp(String): ["disabled", "enabled"]
    # mac_register_mode(String): ["all-host-vlans", "only-native-vlan"]
    # uplink_fail_action(String): ["link-down", "warning"]
    # forge(string): ["allow", "deny"]
    # lldp_transmit(String): ["disabled", "enabled"]
    # lldp_receive(String): ["disabled", "enabled"]
    # descr(String): description
    # parent_dn(String): Parent of Org.

    from ucsmsdk.mometa.nwctrl.NwctrlDefinition import NwctrlDefinition
    from ucsmsdk.mometa.dpsec.DpsecMac import DpsecMac

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org %s is not available" % parent_dn)

    mo = NwctrlDefinition(parent_mo_or_dn=obj,
                          lldp_transmit=nc_policy['lldp_transmit'],
                          name=nc_policy['name'],
                          lldp_receive=nc_policy['lldp_receive'],
                          mac_register_mode=nc_policy['mac_register_mode'],
                          policy_owner="local",
                          cdp=nc_policy['cdp_state'],
                          uplink_fail_action=nc_policy['uplink_fail_action'],
                          descr=nc_policy['descr'])

    DpsecMac(parent_mo_or_dn=mo,
             forge=nc_policy['forge'],
             policy_owner="local",
             name="",
             descr="")

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created Network Control Policy: " + nc_policy['name'] + " in " + parent_dn

    return mo