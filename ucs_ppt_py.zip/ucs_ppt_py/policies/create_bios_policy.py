__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_bios_policy(handle, parent_dn, bios_dict):

    from ucsmsdk.mometa.bios.BiosVProfile import BiosVProfile
    from ucsmsdk.mometa.bios.BiosVfASPMSupport import BiosVfASPMSupport
    from ucsmsdk.mometa.bios.BiosVfAllUSBDevices import BiosVfAllUSBDevices
    from ucsmsdk.mometa.bios.BiosVfAltitude import BiosVfAltitude
    from ucsmsdk.mometa.bios.BiosVfAssertNMIOnPERR import BiosVfAssertNMIOnPERR
    from ucsmsdk.mometa.bios.BiosVfAssertNMIOnSERR import BiosVfAssertNMIOnSERR
    from ucsmsdk.mometa.bios.BiosVfBootOptionRetry import BiosVfBootOptionRetry
    from ucsmsdk.mometa.bios.BiosVfCPUHardwarePowerManagement import BiosVfCPUHardwarePowerManagement
    from ucsmsdk.mometa.bios.BiosVfCPUPerformance import BiosVfCPUPerformance
    from ucsmsdk.mometa.bios.BiosVfConsistentDeviceNameControl import BiosVfConsistentDeviceNameControl
    from ucsmsdk.mometa.bios.BiosVfConsoleRedirection import BiosVfConsoleRedirection
    from ucsmsdk.mometa.bios.BiosVfCoreMultiProcessing import BiosVfCoreMultiProcessing
    from ucsmsdk.mometa.bios.BiosVfDDR3VoltageSelection import BiosVfDDR3VoltageSelection
    from ucsmsdk.mometa.bios.BiosVfDRAMClockThrottling import BiosVfDRAMClockThrottling
    from ucsmsdk.mometa.bios.BiosVfDirectCacheAccess import BiosVfDirectCacheAccess
    from ucsmsdk.mometa.bios.BiosVfDramRefreshRate import BiosVfDramRefreshRate
    from ucsmsdk.mometa.bios.BiosVfEnergyPerformanceTuning import BiosVfEnergyPerformanceTuning
    from ucsmsdk.mometa.bios.BiosVfEnhancedIntelSpeedStepTech import BiosVfEnhancedIntelSpeedStepTech
    from ucsmsdk.mometa.bios.BiosVfExecuteDisableBit import BiosVfExecuteDisableBit
    from ucsmsdk.mometa.bios.BiosVfFRB2Timer import BiosVfFRB2Timer
    from ucsmsdk.mometa.bios.BiosVfFrequencyFloorOverride import BiosVfFrequencyFloorOverride
    from ucsmsdk.mometa.bios.BiosVfFrontPanelLockout import BiosVfFrontPanelLockout
    from ucsmsdk.mometa.bios.BiosVfIOEMezz1OptionROM import BiosVfIOEMezz1OptionROM
    from ucsmsdk.mometa.bios.BiosVfIOENVMe1OptionROM import BiosVfIOENVMe1OptionROM
    from ucsmsdk.mometa.bios.BiosVfIOENVMe2OptionROM import BiosVfIOENVMe2OptionROM
    from ucsmsdk.mometa.bios.BiosVfIOESlot1OptionROM import BiosVfIOESlot1OptionROM
    from ucsmsdk.mometa.bios.BiosVfIOESlot2OptionROM import BiosVfIOESlot2OptionROM
    from ucsmsdk.mometa.bios.BiosVfIntegratedGraphics import BiosVfIntegratedGraphics
    from ucsmsdk.mometa.bios.BiosVfIntegratedGraphicsApertureSize import BiosVfIntegratedGraphicsApertureSize
    from ucsmsdk.mometa.bios.BiosVfIntelHyperThreadingTech import BiosVfIntelHyperThreadingTech
    from ucsmsdk.mometa.bios.BiosVfIntelTrustedExecutionTechnology import BiosVfIntelTrustedExecutionTechnology
    from ucsmsdk.mometa.bios.BiosVfIntelTurboBoostTech import BiosVfIntelTurboBoostTech
    from ucsmsdk.mometa.bios.BiosVfIntelVTForDirectedIO import BiosVfIntelVTForDirectedIO
    from ucsmsdk.mometa.bios.BiosVfIntelVirtualizationTechnology import BiosVfIntelVirtualizationTechnology
    from ucsmsdk.mometa.bios.BiosVfIntelEntrySASRAIDModule import BiosVfIntelEntrySASRAIDModule
    from ucsmsdk.mometa.bios.BiosVfInterleaveConfiguration import BiosVfInterleaveConfiguration
    from ucsmsdk.mometa.bios.BiosVfLocalX2Apic import BiosVfLocalX2Apic
    from ucsmsdk.mometa.bios.BiosVfLvDIMMSupport import BiosVfLvDIMMSupport
    from ucsmsdk.mometa.bios.BiosVfMaxVariableMTRRSetting import BiosVfMaxVariableMTRRSetting
    from ucsmsdk.mometa.bios.BiosVfMaximumMemoryBelow4GB import BiosVfMaximumMemoryBelow4GB
    from ucsmsdk.mometa.bios.BiosVfMemoryMappedIOAbove4GB import BiosVfMemoryMappedIOAbove4GB
    from ucsmsdk.mometa.bios.BiosVfMirroringMode import BiosVfMirroringMode
    from ucsmsdk.mometa.bios.BiosVfNUMAOptimized import BiosVfNUMAOptimized
    from ucsmsdk.mometa.bios.BiosVfOSBootWatchdogTimer import BiosVfOSBootWatchdogTimer
    from ucsmsdk.mometa.bios.BiosVfOSBootWatchdogTimerPolicy import BiosVfOSBootWatchdogTimerPolicy
    from ucsmsdk.mometa.bios.BiosVfOSBootWatchdogTimerTimeout import BiosVfOSBootWatchdogTimerTimeout
    from ucsmsdk.mometa.bios.BiosVfOnboardGraphics import BiosVfOnboardGraphics
    from ucsmsdk.mometa.bios.BiosVfOnboardStorage import BiosVfOnboardStorage
    from ucsmsdk.mometa.bios.BiosVfOptionROMEnable import BiosVfOptionROMEnable
    from ucsmsdk.mometa.bios.BiosVfOutOfBandManagement import BiosVfOutOfBandManagement
    from ucsmsdk.mometa.bios.BiosVfPSTATECoordination import BiosVfPSTATECoordination
    from ucsmsdk.mometa.bios.BiosVfPCILOMPortsConfiguration import BiosVfPCILOMPortsConfiguration
    from ucsmsdk.mometa.bios.BiosVfPCIROMCLP import BiosVfPCIROMCLP
    from ucsmsdk.mometa.bios.BiosVfPCISlotLinkSpeed import BiosVfPCISlotLinkSpeed
    from ucsmsdk.mometa.bios.BiosVfPCISlotOptionROMEnable import BiosVfPCISlotOptionROMEnable
    from ucsmsdk.mometa.bios.BiosVfPOSTErrorPause import BiosVfPOSTErrorPause
    from ucsmsdk.mometa.bios.BiosVfPackageCStateLimit import BiosVfPackageCStateLimit
    from ucsmsdk.mometa.bios.BiosVfProcessorCState import BiosVfProcessorCState
    from ucsmsdk.mometa.bios.BiosVfProcessorC1E import BiosVfProcessorC1E
    from ucsmsdk.mometa.bios.BiosVfProcessorC3Report import BiosVfProcessorC3Report
    from ucsmsdk.mometa.bios.BiosVfProcessorC6Report import BiosVfProcessorC6Report
    from ucsmsdk.mometa.bios.BiosVfProcessorC7Report import BiosVfProcessorC7Report
    from ucsmsdk.mometa.bios.BiosVfProcessorCMCI import BiosVfProcessorCMCI
    from ucsmsdk.mometa.bios.BiosVfProcessorEnergyConfiguration import BiosVfProcessorEnergyConfiguration
    from ucsmsdk.mometa.bios.BiosVfProcessorPrefetchConfig import BiosVfProcessorPrefetchConfig
    from ucsmsdk.mometa.bios.BiosVfQPILinkFrequencySelect import BiosVfQPILinkFrequencySelect
    from ucsmsdk.mometa.bios.BiosVfQPISnoopMode import BiosVfQPISnoopMode
    from ucsmsdk.mometa.bios.BiosVfQuietBoot import BiosVfQuietBoot
    from ucsmsdk.mometa.bios.BiosVfRedirectionAfterBIOSPOST import BiosVfRedirectionAfterBIOSPOST
    from ucsmsdk.mometa.bios.BiosVfResumeOnACPowerLoss import BiosVfResumeOnACPowerLoss
    from ucsmsdk.mometa.bios.BiosVfSBMezz1OptionROM import BiosVfSBMezz1OptionROM
    from ucsmsdk.mometa.bios.BiosVfSBNVMe1OptionROM import BiosVfSBNVMe1OptionROM
    from ucsmsdk.mometa.bios.BiosVfSIOC1OptionROM import BiosVfSIOC1OptionROM
    from ucsmsdk.mometa.bios.BiosVfSIOC2OptionROM import BiosVfSIOC2OptionROM
    from ucsmsdk.mometa.bios.BiosVfScrubPolicies import BiosVfScrubPolicies
    from ucsmsdk.mometa.bios.BiosVfSelectMemoryRASConfiguration import BiosVfSelectMemoryRASConfiguration
    from ucsmsdk.mometa.bios.BiosVfSerialPortAEnable import BiosVfSerialPortAEnable
    from ucsmsdk.mometa.bios.BiosVfTrustedPlatformModule import BiosVfTrustedPlatformModule
    from ucsmsdk.mometa.bios.BiosVfUSBBootConfig import BiosVfUSBBootConfig
    from ucsmsdk.mometa.bios.BiosVfUSBConfiguration import BiosVfUSBConfiguration
    from ucsmsdk.mometa.bios.BiosVfUSBFrontPanelAccessLock import BiosVfUSBFrontPanelAccessLock
    from ucsmsdk.mometa.bios.BiosVfUSBSystemIdlePowerOptimizingSetting import BiosVfUSBSystemIdlePowerOptimizingSetting
    from ucsmsdk.mometa.bios.BiosVfUSBPortConfiguration import BiosVfUSBPortConfiguration
    from ucsmsdk.mometa.bios.BiosVfVGAPriority import BiosVfVGAPriority
    from ucsmsdk.mometa.bios.BiosVfWorkloadConfiguration import BiosVfWorkloadConfiguration

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % parent_dn)

    mo = BiosVProfile(parent_mo_or_dn=obj,
                      policy_owner=bios_dict['policy_owner'],
                      name=bios_dict['name'],
                      descr=bios_dict['descr'],
                      reboot_on_update=bios_dict['reboot_on_update'])

    mo_1 = BiosVfASPMSupport(parent_mo_or_dn=mo,
                             vp_aspm_support=bios_dict['aspm_support'])

    mo_2 = BiosVfAllUSBDevices(parent_mo_or_dn=mo,
                               vp_all_usb_devices=bios_dict['all_usb_devices'])

    mo_3 = BiosVfAltitude(parent_mo_or_dn=mo,
                          vp_altitude=bios_dict['altitude'])

    mo_4 = BiosVfAssertNMIOnPERR(parent_mo_or_dn=mo,
                                 vp_assert_nmi_on_perr=bios_dict['assert_nmi_on_perr'])

    mo_5 = BiosVfAssertNMIOnSERR(parent_mo_or_dn=mo,
                                 vp_assert_nmi_on_serr=bios_dict['assert_nmi_on_serr'])

    mo_6 = BiosVfBootOptionRetry(parent_mo_or_dn=mo,
                                 vp_boot_option_retry=bios_dict['boot_option_retry'])

    mo_7 = BiosVfCPUHardwarePowerManagement(parent_mo_or_dn=mo,
                                            vp_cpu_hardware_power_management=bios_dict['cpu_hardware_power_management'])

    mo_8 = BiosVfCPUPerformance(parent_mo_or_dn=mo,
                                vp_cpu_performance=bios_dict['cpu_performance'])

    mo_9 = BiosVfConsistentDeviceNameControl(parent_mo_or_dn=mo,
                                             vp_cdn_control=bios_dict['cdn_control'])

    mo_10 = BiosVfConsoleRedirection(parent_mo_or_dn=mo,
                                     vp_terminal_type=bios_dict['terminal_type'],
                                     vp_flow_control=bios_dict['flow_control'],
                                     vp_baud_rate=bios_dict['baud_rate'],
                                     vp_putty_key_pad=bios_dict['putty_key_pad'],
                                     vp_console_redirection=bios_dict['console_redirection'],
                                     vp_legacy_os_redirection=bios_dict['legacy_os_redirection'])

    mo_11 = BiosVfCoreMultiProcessing(parent_mo_or_dn=mo,
                                      vp_core_multi_processing=bios_dict['core_multi_processing'])

    mo_12 = BiosVfDDR3VoltageSelection(parent_mo_or_dn=mo,
                                       vp_dd_r3_voltage_selection=bios_dict['dd_r3_voltage_selection'])

    mo_13 = BiosVfDRAMClockThrottling(parent_mo_or_dn=mo,
                                      vp_dram_clock_throttling=bios_dict['dram_clock_throttling'])

    mo_14 = BiosVfDirectCacheAccess(parent_mo_or_dn=mo,
                                    vp_direct_cache_access=bios_dict['direct_cache_access'])

    mo_15 = BiosVfDramRefreshRate(parent_mo_or_dn=mo,
                                  vp_dram_refresh_rate=bios_dict['dram_refresh_rate'])

    mo_16 = BiosVfEnergyPerformanceTuning(parent_mo_or_dn=mo,
                                          vp_pwr_perf_tuning=bios_dict['pwr_perf_tuning'])

    mo_17 = BiosVfEnhancedIntelSpeedStepTech(parent_mo_or_dn=mo,
                                             vp_enhanced_intel_speed_step_tech=bios_dict['enhanced_intel_speed_step_tech'])

    mo_18 = BiosVfExecuteDisableBit(parent_mo_or_dn=mo,
                                    vp_execute_disable_bit=bios_dict['execute_disable_bit'])

    mo_19 = BiosVfFRB2Timer(parent_mo_or_dn=mo,
                            vp_fr_b2_timer=bios_dict['fr_b2_timer'])

    mo_20 = BiosVfFrequencyFloorOverride(parent_mo_or_dn=mo,
                                         vp_frequency_floor_override=bios_dict['frequency_floor_override'])

    mo_21 = BiosVfFrontPanelLockout(parent_mo_or_dn=mo,
                                    vp_front_panel_lockout=bios_dict['front_panel_lockout'])

    mo_22 = BiosVfIOEMezz1OptionROM(parent_mo_or_dn=mo,
                                    vp_ioe_mezz1_option_rom=bios_dict['ioe_mezz1_option_rom'])

    mo_23 = BiosVfIOENVMe1OptionROM(parent_mo_or_dn=mo,
                                    vp_ioenv_me1_option_rom=bios_dict['ioenv_me1_option_rom'])

    mo_24 = BiosVfIOENVMe2OptionROM(parent_mo_or_dn=mo,
                                    vp_ioenv_me2_option_rom=bios_dict['ioenv_me2_option_rom'])

    mo_25 = BiosVfIOESlot1OptionROM(parent_mo_or_dn=mo,
                                    vp_ioe_slot1_option_rom=bios_dict['ioe_slot1_option_rom'])

    mo_26 = BiosVfIOESlot2OptionROM(parent_mo_or_dn=mo,
                                    vp_ioe_slot2_option_rom=bios_dict['ioe_slot2_option_rom'])

    mo_27 = BiosVfIntegratedGraphics(parent_mo_or_dn=mo,
                                     vp_integrated_graphics=bios_dict['integrated_graphics'])

    mo_28 = BiosVfIntegratedGraphicsApertureSize(parent_mo_or_dn=mo,
                                                 vp_integrated_graphics_aperture_size=bios_dict['integrated_graphics_aperture_size'])

    mo_29 = BiosVfIntelHyperThreadingTech(parent_mo_or_dn=mo,
                                          vp_intel_hyper_threading_tech=bios_dict['intel_hyper_threading_tech'])

    mo_30 = BiosVfIntelTrustedExecutionTechnology(parent_mo_or_dn=mo,
                                                  vp_intel_trusted_execution_technology_support=bios_dict['intel_trusted_execution_technology_support'])

    mo_31 = BiosVfIntelTurboBoostTech(parent_mo_or_dn=mo,
                                      vp_intel_turbo_boost_tech=bios_dict['intel_turbo_boost_tech'])

    mo_32 = BiosVfIntelVTForDirectedIO(parent_mo_or_dn=mo,
                                       vp_intel_vtd_pass_through_dma_support=bios_dict['intel_vtd_pass_through_dma_support'],
                                       vp_intel_vtdats_support=bios_dict['intel_vtdats_support'],
                                       vp_intel_vtd_interrupt_remapping=bios_dict['intel_vtd_interrupt_remapping'],
                                       vp_intel_vtd_coherency_support=bios_dict['intel_vtd_coherency_support'],
                                       vp_intel_vt_for_directed_io=bios_dict['intel_vt_for_directed_io'])

    mo_33 = BiosVfIntelVirtualizationTechnology(parent_mo_or_dn=mo,
                                                vp_intel_virtualization_technology=bios_dict['intel_virtualization_technology'])

    mo_34 = BiosVfIntelEntrySASRAIDModule(parent_mo_or_dn=mo,
                                          vp_sasraid=bios_dict['sasraid'],
                                          vp_sasraid_module=bios_dict['sasraid_module'])

    mo_35 = BiosVfInterleaveConfiguration(parent_mo_or_dn=mo,
                                          vp_channel_interleaving=bios_dict['channel_interleaving'],
                                          vp_rank_interleaving=bios_dict['rank_interleaving'],
                                          vp_memory_interleaving=bios_dict['memory_interleaving'])

    mo_36 = BiosVfLocalX2Apic(parent_mo_or_dn=mo,
                              vp_local_x2_apic=bios_dict['local_x2_apic'])

    mo_37 = BiosVfLvDIMMSupport(parent_mo_or_dn=mo,
                                vp_lv_ddr_mode=bios_dict['lv_ddr_mode'])

    mo_38 = BiosVfMaxVariableMTRRSetting(parent_mo_or_dn=mo,
                                         vp_processor_mtrr=bios_dict['processor_mtrr'])

    mo_39 = BiosVfMaximumMemoryBelow4GB(parent_mo_or_dn=mo,
                                        vp_maximum_memory_below4_gb=bios_dict['maximum_memory_below4_gb'])

    mo_40 = BiosVfMemoryMappedIOAbove4GB(parent_mo_or_dn=mo,
                                         vp_memory_mapped_io_above4_gb=bios_dict['memory_mapped_io_above4_gb'])

    mo_41 = BiosVfMirroringMode(parent_mo_or_dn=mo,
                                vp_mirroring_mode=bios_dict['mirroring_mode'])

    mo_42 = BiosVfNUMAOptimized(parent_mo_or_dn=mo,
                                vp_numa_optimized=bios_dict['numa_optimized'])

    mo_43 = BiosVfOSBootWatchdogTimer(parent_mo_or_dn=mo,
                                      vp_os_boot_watchdog_timer=bios_dict['os_boot_watchdog_timer'])

    mo_44 = BiosVfOSBootWatchdogTimerPolicy(parent_mo_or_dn=mo,
                                            vp_os_boot_watchdog_timer_policy=bios_dict['os_boot_watchdog_timer_policy'])

    mo_45 = BiosVfOSBootWatchdogTimerTimeout(parent_mo_or_dn=mo,
                                             vp_os_boot_watchdog_timer_timeout=bios_dict['os_boot_watchdog_timer_timeout'])

    mo_46 = BiosVfOnboardGraphics(parent_mo_or_dn=mo,
                                  vp_onboard_graphics=bios_dict['onboard_graphics'])

    mo_47 = BiosVfOnboardStorage(parent_mo_or_dn=mo,
                                 vp_onboard_scu_storage_support=bios_dict['onboard_scu_storage_support'])

    mo_48 = BiosVfOptionROMEnable(parent_mo_or_dn=mo, )

    mo_49 = BiosVfOutOfBandManagement(parent_mo_or_dn=mo,
                                      vp_com_spcr_enable=bios_dict['com_spcr_enable'])

    mo_50 = BiosVfPSTATECoordination(parent_mo_or_dn=mo,
                                     vp_pstate_coordination=bios_dict['pstate_coordination'])

    mo_51 = BiosVfPCILOMPortsConfiguration(parent_mo_or_dn=mo,
                                           vp_pc_ie10_glo_m2_link=bios_dict['pc_ie10_glo_m2_link'])

    mo_52 = BiosVfPCIROMCLP(parent_mo_or_dn=mo,
                            vp_pciromclp=bios_dict['pciromclp'])

    mo_53 = BiosVfPCISlotLinkSpeed(parent_mo_or_dn=mo,
                                   vp_pc_ie_slot4_link_speed="platform-default",
                                   vp_pc_ie_slot3_link_speed="platform-default",
                                   vp_pc_ie_slot10_link_speed="platform-default",
                                   vp_pc_ie_slot9_link_speed="platform-default",
                                   vp_pc_ie_slot2_link_speed="platform-default",
                                   vp_pc_ie_slot8_link_speed="platform-default",
                                   vp_pc_ie_slot6_link_speed="platform-default",
                                   vp_pc_ie_slot5_link_speed="platform-default",
                                   vp_pc_ie_slot1_link_speed="platform-default",
                                   vp_pc_ie_slot7_link_speed="platform-default")

    mo_54 = BiosVfPCISlotOptionROMEnable(parent_mo_or_dn=mo,
                                         vp_slot3_state="platform-default",
                                         vp_slot4_state="platform-default",
                                         vp_slot1_state="platform-default",
                                         vp_pc_ie_slot_sas_option_rom="platform-default",
                                         vp_pc_ie_slot_hba_option_rom="platform-default",
                                         vp_slot6_state="platform-default",
                                         vp_slot9_state="platform-default",
                                         vp_pc_ie_slot_n2_option_rom="platform-default",
                                         vp_slot7_state="platform-default",
                                         vp_pc_ie_slot_n1_option_rom="platform-default",
                                         vp_slot8_state="platform-default",
                                         vp_slot2_state="platform-default",
                                         vp_slot5_state="platform-default",
                                         vp_slot10_state="platform-default",
                                         vp_pc_ie_slot_mlom_option_rom="platform-default")

    mo_55 = BiosVfPOSTErrorPause(parent_mo_or_dn=mo,
                                 vp_post_error_pause=bios_dict['post_error_pause'])

    mo_56 = BiosVfPackageCStateLimit(parent_mo_or_dn=mo,
                                     vp_package_c_state_limit=bios_dict['package_c_state_limit'])

    mo_57 = BiosVfProcessorCState(parent_mo_or_dn=mo,
                                  vp_processor_c_state=bios_dict['processor_c_state'])

    mo_58 = BiosVfProcessorC1E(parent_mo_or_dn=mo,
                               vp_processor_c1_e=bios_dict['processor_c1_e'])

    mo_59 = BiosVfProcessorC3Report(parent_mo_or_dn=mo,
                                    vp_processor_c3_report=bios_dict['processor_c3_report'])

    mo_60 = BiosVfProcessorC6Report(parent_mo_or_dn=mo,
                                    vp_processor_c6_report=bios_dict['processor_c6_report'])

    mo_61 = BiosVfProcessorC7Report(parent_mo_or_dn=mo,
                                    vp_processor_c7_report=bios_dict['processor_c7_report'])

    mo_62 = BiosVfProcessorCMCI(parent_mo_or_dn=mo,
                                vp_processor_cmci=bios_dict['processor_cmci'])

    mo_63 = BiosVfProcessorEnergyConfiguration(parent_mo_or_dn=mo,
                                               vp_power_technology=bios_dict['power_technology'],
                                               vp_energy_performance=bios_dict['energy_performance'])

    mo_64 = BiosVfProcessorPrefetchConfig(parent_mo_or_dn=mo,
                                          vp_dcuip_prefetcher=bios_dict['dcuip_prefetcher'],
                                          vp_adjacent_cache_line_prefetcher=bios_dict['adjacent_cache_line_prefetcher'],
                                          vp_hardware_prefetcher=bios_dict['hardware_prefetcher'],
                                          vp_dcu_streamer_prefetch=bios_dict['dcu_streamer_prefetch'])

    mo_65 = BiosVfQPILinkFrequencySelect(parent_mo_or_dn=mo,
                                         vp_qpi_link_frequency_select=bios_dict['qpi_link_frequency_select'])

    mo_66 = BiosVfQPISnoopMode(parent_mo_or_dn=mo,
                               vp_qpi_snoop_mode=bios_dict['qpi_snoop_mode'])

    mo_67 = BiosVfQuietBoot(parent_mo_or_dn=mo,
                            vp_quiet_boot=bios_dict['quiet_boot'])

    mo_68 = BiosVfRedirectionAfterBIOSPOST(parent_mo_or_dn=mo,
                                           vp_redirection_after_post=bios_dict['redirection_after_post'])

    mo_69 = BiosVfResumeOnACPowerLoss(parent_mo_or_dn=mo,
                                      vp_resume_on_ac_power_loss=bios_dict['resume_on_ac_power_loss'])

    mo_70 = BiosVfSBMezz1OptionROM(parent_mo_or_dn=mo,
                                   vp_sb_mezz1_option_rom=bios_dict['sb_mezz1_option_rom'])

    mo_71 = BiosVfSBNVMe1OptionROM(parent_mo_or_dn=mo,
                                   vp_sbnv_me1_option_rom=bios_dict['sbnv_me1_option_rom'])

    mo_72 = BiosVfSIOC1OptionROM(parent_mo_or_dn=mo,
                                 vp_sio_c1_option_rom=bios_dict['sio_c1_option_rom'])

    mo_73 = BiosVfSIOC2OptionROM(parent_mo_or_dn=mo,
                                 vp_sio_c2_option_rom=bios_dict['sio_c2_option_rom'])

    mo_74 = BiosVfScrubPolicies(parent_mo_or_dn=mo,
                                vp_patrol_scrub=bios_dict['patrol_scrub'],
                                vp_demand_scrub=bios_dict['demand_scrub'])

    mo_75 = BiosVfSelectMemoryRASConfiguration(parent_mo_or_dn=mo,
                                               vp_select_memory_ras_configuration=bios_dict['select_memory_ras_configuration'])

    mo_76 = BiosVfSerialPortAEnable(parent_mo_or_dn=mo,
                                    vp_serial_port_a_enable=bios_dict['serial_port_a_enable'])

    mo_77 = BiosVfTrustedPlatformModule(parent_mo_or_dn=mo,
                                        vp_trusted_platform_module_support=bios_dict['trusted_platform_module_support'])

    mo_78 = BiosVfUSBBootConfig(parent_mo_or_dn=mo,
                                vp_legacy_usb_support=bios_dict['legacy_usb_support_boot'],
                                vp_make_device_non_bootable=bios_dict['make_device_non_bootable'])

    mo_79 = BiosVfUSBConfiguration(parent_mo_or_dn=mo,
                                   vp_xhci_mode=bios_dict['xhci_mode'],
                                   vp_legacy_usb_support=bios_dict['legacy_usb_support'])

    mo_80 = BiosVfUSBFrontPanelAccessLock(parent_mo_or_dn=mo,
                                          vp_usb_front_panel_lock=bios_dict['usb_front_panel_lock'])

    mo_81 = BiosVfUSBSystemIdlePowerOptimizingSetting(parent_mo_or_dn=mo,
                                                      vp_usb_idle_power_optimizing=bios_dict['usb_idle_power_optimizing'])

    mo_82 = BiosVfUSBPortConfiguration(parent_mo_or_dn=mo,
                                       vp_usb_port_front=bios_dict['usb_port_front'],
                                       vp_usb_port_v_media=bios_dict['usb_port_v_media'],
                                       vp_usb_port_kvm=bios_dict['usb_port_kvm'],
                                       vp_port6064_emulation=bios_dict['port6064_emulation'],
                                       vp_usb_port_rear=bios_dict['usb_port_rear'],
                                       vp_usb_port_internal=bios_dict['usb_port_internal'],
                                       vp_usb_port_sd_card=bios_dict['usb_port_sd_card'])

    mo_83 = BiosVfVGAPriority(parent_mo_or_dn=mo,
                              vp_vga_priority=bios_dict['vga_priority'])

    mo_84 = BiosVfWorkloadConfiguration(parent_mo_or_dn=mo,
                                        vp_workload_configuration=bios_dict['workload_configuration'])

    handle.add_mo(mo)
    handle.commit()

    print "Created BIOS policy: " + bios_dict['name'] + " in " + parent_dn