__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def add_vnic_lan_conn(handle, parent_dn, lan_conn_dict, lan_adapters_dict):

    from ucsmsdk.mometa.vnic.VnicEther import VnicEther

    vnic_dn = parent_dn + "/lan-conn-pol-" + lan_conn_dict['name']
    obj = handle.query_dn(vnic_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % vnic_dn)

    for adapters in lan_adapters_dict:
        mo = VnicEther(parent_mo_or_dn=obj,
                       name=lan_adapters_dict[adapters]['name'],
                       adaptor_profile_name=lan_adapters_dict[adapters]['adapter_profile'],
                       order=lan_adapters_dict[adapters]['adapter_order'],
                       nw_templ_name=lan_adapters_dict[adapters]['vnic_temp'])

        handle.add_mo(mo, modify_present=True)

        print "Added vNIC: " + lan_adapters_dict[adapters]['name'] + " to LAN connectivity policy " + lan_conn_dict['name']

    handle.commit()