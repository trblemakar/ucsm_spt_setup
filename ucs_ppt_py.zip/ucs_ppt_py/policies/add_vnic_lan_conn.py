__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def add_vnic_lan_conn(handle, lan_conn, lan_adapters):

    from ucsmsdk.mometa.vnic.VnicEther import VnicEther

    parent_dn = lan_conn['parent_dn'] + "/lan-conn-pol-" + lan_conn['name']
    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % lan_conn['parent_dn'])

    for adapters in lan_adapters:
        mo = VnicEther(parent_mo_or_dn=obj,
                       name=adapters,
                       adaptor_profile_name=lan_adapters[adapters]['adapter_profile'],
                       order=lan_adapters[adapters]['adapter_order'],
                       nw_templ_name=lan_adapters[adapters]['vnic_temp'])

        handle.add_mo(mo, modify_present=True)

        print "Added vNIC: " + adapters + " to LAN connectivity policy " + lan_conn['name']

    handle.commit()

    return mo