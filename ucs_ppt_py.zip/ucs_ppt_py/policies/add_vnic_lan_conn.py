__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

#def add_vnic_lan_conn(handle, parent_dn,  name, nw_ctrl_policy_name="",
#                      admin_host_port="ANY", admin_vcon="any",
#                      stats_policy_name="default", admin_cdn_name="",
#                      switch_id="A", pin_to_group_name="", mtu="1500",
#                      qos_policy_name="", adaptor_profile_name="",
#                      ident_pool_name="", order="1", nw_templ_name="", addr="derived"):

def add_vnic_lan_conn(handle, parent_dn, name, temp):

    # Adds vNIC to LAN Connectivity Policy
    # Args:
    # handle (UcsHandle)
    # parent_dn (string): dn of VnicLanConnPolicy
    # name (string): name of vnic
    # nw_ctrl_policy_name (string): network control policy name
    # admin_host_port (number): admin host port
    # admin_vcon (string): ["1", "2", "3", "4", "any"]
    # stats_policy_name (string): stats policy name
    # admin_cdn_name (string): admin cdn name
    # switch_id (string): ["A", "A-B", "B", "B-A", "NONE"]
    # pin_to_group_name (string): pin to group name
    # mtu (number):1500-9000
    # qos_policy_name (string): qos policy name
    # adaptor_profile_name (string): adaptor profile name
    # ident_pool_name (string): ident pool name
    # order (string):["unspecified"], ["0-256"]
    # nw_templ_name (string): network template name
    # addr (string): address

    from ucsmsdk.mometa.vnic.VnicEther import VnicEther

    obj = handle.query_dn(parent_dn)
    if obj:
        mo = VnicEther(parent_mo_or_dn=obj,
                       name=name,
                       adaptor_profile_name=temp['adapter_profile'],
                       order=temp['adapter_order'],
                       nw_templ_name=temp['vnic_temp'])

        handle.add_mo(mo, modify_present=True)
        handle.commit()

        print "Added vNIC: " + name + " to LAN connectivity policy"

        return mo
    else:
        raise ValueError(parent_dn + " MO is not available")