__author__ = 'jamakar'

def create_lan_conn_policy(handle, lan_conn_details):

    from ucsmsdk.mometa.vnic.VnicLanConnPolicy import VnicLanConnPolicy

    parent_dn = lan_conn_details['parent_dn']
    obj = handle.query_dn(parent_dn)

    mo = VnicLanConnPolicy(parent_mo_or_dn=obj,
                           name=lan_conn_details['name'],
                           descr=lan_conn_details['descr'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created LAN connectivity policy: " + lan_conn_details['name'] + " in " + parent_dn