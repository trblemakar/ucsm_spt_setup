__author__ = 'jamakar'

def create_lan_conn_policy(handle, name, descr="", parent_dn="org-root"):

    # Args:
    # handle (UcsHandle)
    # name (String) : LAN Connectivity Policy name
    # descr (String) : description
    # parent_dn (String) : org dn

    from ucsmsdk.mometa.vnic.VnicLanConnPolicy import VnicLanConnPolicy

    obj = handle.query_dn(parent_dn)
    if obj is None:
        raise ValueError("Org %s not found" % parent_dn)
    mo = VnicLanConnPolicy(parent_mo_or_dn=obj,
                           policy_owner="local",
                           name=name,
                           descr=descr)

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created LAN connectivity policy: " + name, "in " + parent_dn

    return mo