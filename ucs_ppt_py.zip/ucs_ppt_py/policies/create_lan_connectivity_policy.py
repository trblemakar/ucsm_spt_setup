__author__ = 'jamakar'

def create_lan_conn_policy(handle, parent_dn, lan_conn_details_dict):

    # Args:
    # handle (UcsHandle)
    # name (string): Name of the LAN connectivity policy
    # descr (string): Basic description.
    # parent_dn (string): Parent of Org.

    from ucsmsdk.mometa.vnic.VnicLanConnPolicy import VnicLanConnPolicy

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % parent_dn)

    mo = VnicLanConnPolicy(parent_mo_or_dn=obj,
                           name=lan_conn_details_dict['name'],
                           descr=lan_conn_details_dict['descr'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created LAN connectivity policy: " + lan_conn_details_dict['name'] + " in " + parent_dn