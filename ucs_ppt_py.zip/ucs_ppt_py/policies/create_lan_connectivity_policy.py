__author__ = 'jamakar'

def create_lan_conn_policy(handle, lan_conn_details):

    # Args:
    # handle (UcsHandle)
    # name (string): Name of the LAN connectivity policy
    # descr (string): Basic description.
    # parent_dn (string): Parent of Org.

    from ucsmsdk.mometa.vnic.VnicLanConnPolicy import VnicLanConnPolicy

    obj = handle.query_dn(lan_conn_details['parent_dn'])

    if not obj:
        raise ValueError("org '%s' does not exist" % lan_conn_details['parent_dn'])

    mo = VnicLanConnPolicy(parent_mo_or_dn=obj,
                           name=lan_conn_details['name'],
                           descr=lan_conn_details['descr'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created LAN connectivity policy: " + lan_conn_details['name'] + " in " + lan_conn_details['parent_dn']

    return mo