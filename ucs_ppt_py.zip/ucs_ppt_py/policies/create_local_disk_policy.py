__author__ = 'jamakar'

def create_local_disk_policy(handle, parent_dn, ld_policy):

    # Args:
    # handle (UcsHandle)
    # name (string): Name of the local disk policy.
    # mode (string): no-local-storage, raid-mirrored, any-configuration...
    # flex_state (string): "enable" or "disable"
    # flex_raid (string): "enable" or "disable"
    # protect_config (string): "yes" or "no"
    # descr (string): Basic description.
    # parent_dn (string): Parent of Org.

    from ucsmsdk.mometa.storage.StorageLocalDiskConfigPolicy import \
        StorageLocalDiskConfigPolicy

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % parent_dn)

    mo = StorageLocalDiskConfigPolicy(
        parent_mo_or_dn=obj,
        protect_config=ld_policy['protect'],
        name=ld_policy['name'],
        descr=ld_policy['descr'],
        flex_flash_raid_reporting_state=ld_policy['flex_raid'],
        flex_flash_state=ld_policy['flex_state'],
        mode=ld_policy['mode'])

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created Local Disk Policy: " + ld_policy['name'] + " in " + parent_dn

    return mo