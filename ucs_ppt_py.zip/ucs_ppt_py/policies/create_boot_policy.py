__author__ = 'jamakar'

def create_boot_policy(handle, parent_dn, boot_policy):

    from ucsmsdk.mometa.lsboot.LsbootPolicy import LsbootPolicy
    from ucsmsdk.mometa.lsboot.LsbootVirtualMedia import LsbootVirtualMedia
    from ucsmsdk.mometa.lsboot.LsbootStorage import LsbootStorage
    from ucsmsdk.mometa.lsboot.LsbootLocalStorage import LsbootLocalStorage
    from ucsmsdk.mometa.lsboot.LsbootDefaultLocalImage import LsbootDefaultLocalImage
    from ucsmsdk.mometa.lsboot.LsbootUsbFlashStorageImage import LsbootUsbFlashStorageImage

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % parent_dn)

    mo = LsbootPolicy(parent_mo_or_dn=obj,
                      name=boot_policy['name'],
                      descr=boot_policy['descr'],
                      reboot_on_update=boot_policy['reboot_on_update'],
                      policy_owner="local",
                      enforce_vnic_name=boot_policy['enforce_vnic_name'],
                      boot_mode=boot_policy['boot_mode'])

    # Select the boot media
    for type in boot_policy['media']:
        media = boot_policy['media'][type]
        if type == "vMedia":
            # vMedia (CD/DVD)
            mo_1 = LsbootVirtualMedia(parent_mo_or_dn=mo, access="read-only", lun_id="0", mapping_name="", order=media['order'])
        elif type == "HDD/SSD":
            # Local disk
            mo_2 = LsbootStorage(parent_mo_or_dn=mo, order=media['order'])
            mo_2_1 = LsbootLocalStorage(parent_mo_or_dn=mo_2, )
            mo_2_1_1 = LsbootDefaultLocalImage(parent_mo_or_dn=mo_2_1, order=media['order'])
        elif type == "FlexFlash":
            # FlexFlash (SD Card)
            mo_2 = LsbootStorage(parent_mo_or_dn=mo, order=media['order'])
            mo_2_1 = LsbootLocalStorage(parent_mo_or_dn=mo_2, )
            mo_2_1_1 = LsbootUsbFlashStorageImage(parent_mo_or_dn=mo_2_1, order=media['order'])
        else:
            raise ValueError("Media '%s' does not exist" % type)

    handle.add_mo(mo)
    handle.commit()

    print "Created Boot policy: " + boot_policy['name'] + " in " + parent_dn

    return mo