__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def add_vhba_san_conn(handle, san_conn_dict):

    from ucsmsdk.mometa.vnic.VnicSanConnPolicy import VnicSanConnPolicy
    from ucsmsdk.mometa.vnic.VnicFc import VnicFc
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf
    from ucsmsdk.mometa.vnic.VnicFcNode import VnicFcNode

    for san_conn_name in san_conn_dict:
        adapters_dict = san_conn_dict[san_conn_name]

        obj = handle.query_dn(parent_dn)

        mo = VnicSanConnPolicy(parent_mo_or_dn=obj, policy_owner="local", name=san_conn_name, descr="")

        for adapters in adapters_dict:
            #adapter_dn = san_conn_dn + "/fc-" + adapters
            wwnn_pool = adapters_dict[adapters]['wwnn_pool']

            mo_1 = VnicFc(parent_mo_or_dn=mo, cdn_prop_in_sync="yes", addr="derived", admin_host_port="ANY",
                          admin_vcon="any", stats_policy_name="default", admin_cdn_name="", switch_id="B",
                          pin_to_group_name="", pers_bind="disabled", order="2", pers_bind_clear="no",
                          qos_policy_name="", adaptor_profile_name="VMWare", ident_pool_name="", cdn_source="vnic-name",
                          max_data_field_size="2048", nw_templ_name="esx_vhba_B", name="fc1")

            mo_1_1 = VnicFcIf(parent_mo_or_dn=mo_1, name="")

            mo_2 = VnicFcNode(parent_mo_or_dn=mo, ident_pool_name=wwnn_pool, addr="pool-derived")

            handle.add_mo(mo)
            handle.commit()

        print "Added vHBA " + san_conn_name