__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def add_vhba_san_conn(handle, parent_dn, san_conn_dict, san_adapters_dict):

    from ucsmsdk.mometa.vnic.VnicFc import VnicFc
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf

    vhba_dn = parent_dn + "/san-conn-pol-" + san_conn_dict['name']
    obj = handle.query_dn(vhba_dn)

    if not obj:
        raise ValueError("org '%s' does not exist" % vhba_dn)

    for adapters in san_adapters_dict:
        mo = VnicFc(parent_mo_or_dn=obj,
                    switch_id=san_adapters_dict[adapters]['fabric_id'],
                    order=san_adapters_dict[adapters]['adapter_order'],
                    adaptor_profile_name=san_adapters_dict[adapters]['adapter_profile'],
                    nw_templ_name=san_adapters_dict[adapters]['vhba_temp'],
                    name=san_adapters_dict[adapters]['name'])

        mo_1 = VnicFcIf(parent_mo_or_dn=mo, name="")

        handle.add_mo(mo)

        print "Added vHBA: " + san_adapters_dict[adapters]['name'] + " to SAN connectivity policy " + san_conn_dict['name']

    handle.commit()