__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def add_vhba_san_conn(handle, san_conn, san_adapters):

    from ucsmsdk.mometa.vnic.VnicFc import VnicFc
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf

    parent_dn = san_conn['parent_dn'] + "/san-conn-pol-" + san_conn['name']
    obj = handle.query_dn(parent_dn)

    for adapters in san_adapters:
        mo = VnicFc(parent_mo_or_dn=obj, switch_id=san_adapters[adapters]['fabric_id'],
                    order=san_adapters[adapters]['adapter_order'],
                    adaptor_profile_name=san_adapters[adapters]['adapter_profile'],
                    nw_templ_name=san_adapters[adapters]['vhba_temp'],
                    name=adapters)
        mo_1 = VnicFcIf(parent_mo_or_dn=mo, name="")
        handle.add_mo(mo)

        print "Added vHBA: " + adapters + " to SAN connectivity policy " + san_conn['name']

    handle.commit()