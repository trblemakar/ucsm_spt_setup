__author__ = 'jamakar'

# Uses an input file to build the UCS Orgs, Maintenance policy, NCP policy, VLANs, UUID, MAC, WWNN and WWPN pools
#    vNICs, vHBAs, LAN connectivity policies, SAN connectivity ploicies...
# Requires the UCS Python SDK v0.9+

# Usage: python deploy_ucs -i <ucs_vip> -u <user_name> -c <json_config_file>

import optparse
import json
from utilities.getpassword import getpassword
from ucsmsdk.ucshandle import UcsHandle
from ucsmsdk.mometa.org import OrgOrg
from fabric.create_org import create_org
from fabric.create_vlan import create_vlan
from policies.create_maintenance_policy import create_maintenance_policy
from policies.create_nc_policy import create_nc_policy
from policies.create_local_disk_policy import create_local_disk_policy
from policies.create_boot_policy import create_boot_policy
from pools.build_mac_pool import create_mac_pool
from pools.build_wwnn_pool import create_wwnn_pool
from pools.build_wwpn_pool import create_wwpn_pool
from pools.build_uuid_pool import create_uuid_pool
from templates.create_vnic_template import create_vnic_template
from templates.create_vhba_template import create_vhba_template
from policies.create_lan_connectivity_policy import create_lan_conn_policy
from policies.add_vnic_lan_conn import add_vnic_lan_conn
from policies.create_san_connectivity_policy import create_san_connectivity_policy
from policies.add_vhba_san_conn import add_vhba_san_conn

if __name__ == "__main__":
    try:
        parser = optparse.OptionParser()
        parser.add_option('-i', '--ip', dest="ip",
                          help="[Mandatory] UCSM IP Address")
        parser.add_option('-u', '--username', dest="userName",
                          help="[Mandatory] Account Username for UCSM Login")
        parser.add_option('-c', '--config_file', dest="config_file",
                          help="[Mandatory] Config File for UCSM")
        parser.add_option('-p', '--password', dest="password",
                          help="If not entered the command line will prompt for password")

        (options, args) = parser.parse_args()

        if not options.ip:
            parser.print_help()
            parser.error("Please Provide UCSM IP Address")
        if not options.userName:
            parser.print_help()
            parser.error("Please Provide UCSM UserName")
        if not options.config_file:
            parser.print_help()
            parser.error("Please Provide Config File")
        if not options.password:
            options.password = getpassword("Please Enter UCSM Password:")

        handle = UcsHandle(options.ip, options.userName, options.password)
        handle.login()

    except Exception, err:
        print "Exception:", str(err)
        import traceback
        import sys
        print '-'*60
        traceback.print_exc(file=sys.stdout)
        print '-'*60

    try:
        try:
            json_config_data = open(options.config_file)
            json_input_dict = {}
            json_input_dict = json.load(json_config_data)
        except IOError:
            print("*** Error loading UCS Config file... ***")

        # Load input values from json file
        for orgs in json_input_dict:
            parent_dn = "org-root"
            ucs_config = json_input_dict[orgs]
            org_name = ucs_config['name']
            org_descr = ucs_config['descr']

            # Create Org and set parent_dn to new org
            if org_name != "none":
                create_org(handle, parent_dn, org_name, org_descr)
                parent_dn = parent_dn + "/org-" + org_name

            # Create VLANs if not already created
            org_vlans = ucs_config['vlans']
            if org_vlans != "none":
                create_vlan(handle, org_vlans)

            # Create maintenance policy
            org_maintenance_policy = ucs_config['maintenance_policy']
            create_maintenance_policy(handle, parent_dn, org_maintenance_policy)

            # Create network control policy
            org_nc_policy = ucs_config['network_control_policy']
            create_nc_policy(handle, parent_dn, org_nc_policy)

            # Create local disk policy
            org_ld_policy = ucs_config['local_disk_policy']
            create_local_disk_policy(handle, parent_dn, org_ld_policy)

            # Create boot policy
            org_boot_policy = ucs_config['boot_policy']
            create_boot_policy(handle, parent_dn, org_boot_policy)

            # Create the ID pools
            org_id_pools = ucs_config['id_pools']
            for pools in org_id_pools:
                pool_type = org_id_pools[pools]['type']
                pool_name = org_id_pools[pools]['name']
                pool_assignment_order = org_id_pools[pools]['assignment_order']
                pool_from = org_id_pools[pools]['from']
                pool_to = org_id_pools[pools]['to']
                pool_descr = org_id_pools[pools]['descr']

                if pool_type == "uuid":
                    create_uuid_pool(handle, pool_name, pool_assignment_order,
                                     pool_from, pool_to, pool_descr, parent_dn)
                elif pool_type == "wwnn":
                    create_wwnn_pool(handle, pool_name, pool_assignment_order,
                                    pool_from, pool_to, pool_descr, parent_dn)
                elif pool_type == "wwpn":
                    create_wwpn_pool(handle, pool_name, pool_assignment_order,
                                    pool_from, pool_to, pool_descr, parent_dn)
                elif pool_type == "mac":
                    create_mac_pool(handle, pool_name, pool_assignment_order,
                                    pool_from, pool_to, pool_descr, parent_dn)

            # Create vNIC templates
            org_vnics = ucs_config['vnics']
            for vnic_names in org_vnics:
                vnic_descr = org_vnics[vnic_names]['descr']
                vnic_mac_pool = org_vnics[vnic_names]['mac_pool']
                vnic_vlan_list = org_vnics[vnic_names]['vlan_list']
                vnic_switch_id = org_vnics[vnic_names]['switch_id']
                vnic_mtu = org_vnics[vnic_names]['mtu']
                vnic_con_policy_type = org_vnics[vnic_names]['con_policy_type']
                vnic_con_policy_name = org_vnics[vnic_names]['con_policy_name']
                vnic_qos_policy_name = org_vnics[vnic_names]['qos_policy_name']
                vnic_target = org_vnics[vnic_names]['target']
                vnic_nw_ctrl_policy_name = org_vnics[vnic_names]['nw_ctrl_policy_name']
                vnic_pin_to_group_name = org_vnics[vnic_names]['pin_to_group_name']
                vnic_stats_policy_name = org_vnics[vnic_names]['stats_policy_name']
                vnic_templ_type = org_vnics[vnic_names]['templ_type']

                create_vnic_template(handle, vnic_names, vnic_vlan_list, vnic_con_policy_type,
                                     vnic_con_policy_name, vnic_mtu, vnic_qos_policy_name,
                                     vnic_target, vnic_mac_pool, vnic_nw_ctrl_policy_name,
                                     vnic_pin_to_group_name, vnic_switch_id,
                                     vnic_stats_policy_name, vnic_templ_type, vnic_descr, parent_dn)

            # Create LAN connectivity policy
            org_lan_conn = ucs_config['lan_conn']
            org_lan_conn_details = org_lan_conn['details']
            create_lan_conn_policy(handle, parent_dn, org_lan_conn_details)

            # add vnics to LAN connectivity policy
            org_lan_adapters = org_lan_conn['adapters']
            add_vnic_lan_conn(handle, parent_dn, org_lan_conn_details, org_lan_adapters)

            # Create vHBA templates
            org_vhbas = ucs_config['vhbas']
            if org_vhbas != "none":
                for vhba_names in org_vhbas:
                    vhba_descr = org_vhbas[vhba_names]['descr']
                    vhba_wwpn_pool = org_vhbas[vhba_names]['wwpn_pool']
                    vhba_vsan_name = org_vhbas[vhba_names]['vsan_name']
                    vhba_fabric_id = org_vhbas[vhba_names]['fabric_id']
                    vhba_pin_to_group_name = org_vhbas[vhba_names]['pin_to_group_name']
                    vhba_stats_policy_name = org_vhbas[vhba_names]['stats_policy_name']
                    vhba_templ_type = org_vhbas[vhba_names]['templ_type']

                    create_vhba_template(handle, vhba_descr, vhba_names, vhba_wwpn_pool,
                                         vhba_fabric_id, vhba_vsan_name, vhba_pin_to_group_name,
                                         vhba_stats_policy_name, vhba_templ_type, parent_dn)

                # Create SAN connectivity policy
                org_san_conn = ucs_config['san_conn']
                org_san_conn_details = org_san_conn['details']
                create_san_connectivity_policy(handle, parent_dn, org_san_conn_details)

                # Add vhbas to SAN connectivity policy
                org_san_adapters = org_san_conn['adapters']
                add_vhba_san_conn(handle, parent_dn, org_san_conn_details, org_san_adapters)

        # Close UCSM session
        handle.logout()

    except IOError:
        print("*** UCS Config Error ***")

else:
    exit()