__author__ = 'jamakar'

# Uses an input file to build the UCS Orgs, Maintenance policy, NCP policy, VLANs, UUID, MAC, WWNN and WWPN pools
#    vNICs, vHBAs, LAN connectivity policies, SAN connectivity ploicies...
# Requires the UCS Python SDK v0.9+

# Usage: python deploy_ucs_ppt.py

import json
from utilities.getpassword import getpassword
from ucsmsdk.ucshandle import UcsHandle
from ucsmsdk.mometa.org import OrgOrg
from fabric.create_org import create_org
from fabric.create_vlan import create_vlan
from policies.create_maintenance_policy import create_maintenance_policy
from policies.create_nc_policy import create_nc_policy
from policies.create_local_disk_policy import create_local_disk_policy
from policies.create_boot_policy import create_boot_policy
from policies.create_lan_connectivity_policy import create_lan_conn_policy
from policies.add_vnic_lan_conn import add_vnic_lan_conn
from policies.create_san_connectivity_policy import create_san_connectivity_policy
from policies.add_vhba_san_conn import add_vhba_san_conn
from pools.create_mac_pool import create_mac_pool
from pools.create_wwnn_pool import create_wwnn_pool
from pools.create_wwpn_pool import create_wwpn_pool
from pools.create_uuid_pool import create_uuid_pool
from pools.create_ip_pool import create_ip_pool
from templates.create_vnic_template import create_vnic_template
from templates.create_vhba_template import create_vhba_template
from templates.init_sp_temp_dict import init_sp_temp_dict
from templates.create_sp_template import create_sp_template

if __name__ == "__main__":

    try:
        json_config_file = raw_input("Please Enter UCS[.json] config filename: ")
        ucsmvip = raw_input("Please Enter UCSM VIP Address: ")
        username = raw_input("Please Enter UCSM Username: ")
        password = getpassword("Please Enter UCSM Password: ")

    except IOError:
        print("*** Input Error ***")

    try:
        # Open UCSM session
        handle = UcsHandle(ucsmvip, username, password)
        handle.login()

        # Load json file
        config_data = open(json_config_file)
        ucs_config = {}
        ucs_config = json.load(config_data)

        # Initialize service profile template dictionary
        sp_temp_dict = init_sp_temp_dict(ucs_config['sp_temp_name'], ucs_config['sp_temp_descr'])

        # Create Org and set parent_dn to new org
        parent_dn = "org-root"
        org_name = ucs_config['org_name']
        if org_name != "none":
            org_descr = ucs_config['org_descr']
            create_org(handle, parent_dn, org_name, org_descr)
            parent_dn = parent_dn + "/org-" + org_name

        # Create VLANs if not already created
        vlans = ucs_config['vlans']
        if vlans != "none":
            create_vlan(handle, vlans)

        # Create maintenance policy
        maintenance_policy = ucs_config['maintenance_policy']
        sp_temp_dict['maint_policy_name'] = create_maintenance_policy(handle, parent_dn, maintenance_policy)

        # Create network control policy
        nc_policy = ucs_config['network_control_policy']
        create_nc_policy(handle, parent_dn, nc_policy)

        # Create local disk policy
        ld_policy = ucs_config['local_disk_policy']
        sp_temp_dict['local_disk_policy_name'] = create_local_disk_policy(handle, parent_dn, ld_policy)

        # Create boot policy
        boot_policy = ucs_config['boot_policy']
        sp_temp_dict['boot_policy_name'] = create_boot_policy(handle, parent_dn, boot_policy)

        # Create the ID pools
        id_pools = ucs_config['id_pools']
        for pool in id_pools:
            pool_type = id_pools[pool]['type']

            if pool_type == "uuid":
                sp_temp_dict['ident_pool_name'] = create_uuid_pool(handle, parent_dn, id_pools[pool])
            elif pool_type == "wwnn":
                create_wwnn_pool(handle, parent_dn, id_pools[pool])
            elif pool_type == "wwpn":
                create_wwpn_pool(handle, parent_dn, id_pools[pool])
            elif pool_type == "mac":
                create_mac_pool(handle, parent_dn, id_pools[pool])

        # Create KVM IP pool
        ip_pool = ucs_config['ip_pool']
        if ip_pool != "none":
            sp_temp_dict['ext_ip_pool_name'] = create_ip_pool(handle, parent_dn, ip_pool)
            sp_temp_dict['ext_ip_state'] = "pooled"

        # Create vNIC templates
        vnics = ucs_config['vnics']
        for vnic in vnics:
            create_vnic_template(handle, parent_dn, vnic, vnics[vnic])

        # Create LAN connectivity policy
        lan_conn = ucs_config['lan_conn']
        lan_conn_details = lan_conn['details']
        sp_temp_dict['lan_conn_policy_name'] = create_lan_conn_policy(handle, parent_dn, lan_conn_details)

        # Add vnics to LAN connectivity policy
        lan_adapters = lan_conn['adapters']
        add_vnic_lan_conn(handle, parent_dn, lan_conn_details, lan_adapters)

        # Create vHBA templates and SAN connectivity policy
        vhbas = ucs_config['vhbas']
        if vhbas != "none":
            for vhba in vhbas:
                create_vhba_template(handle, parent_dn, vhba, vhbas[vhba])

            # Create SAN connectivity policy
            san_conn = ucs_config['san_conn']
            san_conn_details = san_conn['details']
            sp_temp_dict['san_conn_policy_name'] = create_san_connectivity_policy(handle, parent_dn,
                                                                                  san_conn_details)

            # Add vhbas to SAN connectivity policy
            san_adapters = san_conn['adapters']
            add_vhba_san_conn(handle, parent_dn, san_conn_details, san_adapters)

        # Create Service Profile template
        create_sp_template(handle, parent_dn, sp_temp_dict)

        # Close UCSM session
        handle.logout()

    except IOError:
        print("*** UCS Config Error ***")

else:
    exit()