__author__ = 'jamakar'

# Uses an input file to create an optimized bios policy
# Requires the UCS Python SDK v0.9+

# Usage: python deploy_ucs_bios.py -i <ucs_vip> -u <user_name> -c <json_config_file>
# Run after running deploy_ucs_ppt.py

import optparse
import json
from utilities.getpassword import getpassword
from ucsmsdk.ucshandle import UcsHandle
from ucsmsdk.mometa.org import OrgOrg
from fabric.create_org import create_org
from policies.create_bios_policy import create_bios_policy

if __name__ == "__main__":
    try:
        parser = optparse.OptionParser()
        parser.add_option('-i', '--ip', dest="ip",
                          help="[Mandatory] UCSM IP Address")
        parser.add_option('-u', '--username', dest="userName",
                          help="[Mandatory] Account Username for UCSM Login")
        parser.add_option('-c', '--config_file', dest="config_file",
                          help="[Mandatory] Config File for UCSM")
        parser.add_option('-p', '--password', dest="password",
                          help="If not entered the command line will prompt for password")

        (options, args) = parser.parse_args()

        if not options.ip:
            parser.print_help()
            parser.error("Please Provide UCSM IP Address")
        if not options.userName:
            parser.print_help()
            parser.error("Please Provide UCSM UserName")
        if not options.config_file:
            parser.print_help()
            parser.error("Please Provide Config File")
        if not options.password:
            options.password = getpassword("Please Enter UCSM Password:")

        handle = UcsHandle(options.ip, options.userName, options.password)
        handle.login()

    except Exception, err:
        print "Exception:", str(err)
        import traceback
        import sys
        print '-'*60
        traceback.print_exc(file=sys.stdout)
        print '-'*60

    try:
        try:
            json_config_data = open(options.config_file)
            json_input_dict = {}
            json_input_dict = json.load(json_config_data)
        except IOError:
            print("*** Error loading UCS Config file... ***")

        # Load input values from json file
        for orgs in json_input_dict:
            parent_dn = "org-root"
            ucs_config = json_input_dict[orgs]
            org_name = ucs_config['name']

            # Set parent_dn to org
            if org_name != "none":
                parent_dn = parent_dn + "/org-" + org_name

            # Create BIOS policy
            org_bios_policy = ucs_config['bios_policy']
            create_bios_policy(handle, parent_dn, org_bios_policy)

            # Add BIOS policy to Service Profile template


        # Close UCSM session
        handle.logout()

    except IOError:
        print("*** UCS Config Error ***")

else:
    exit()