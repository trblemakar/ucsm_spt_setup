__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_vhba_template(handle, descr, name, wwpn_pool, fabric_id, vsan_name, pin_to_group_name,
                         stats_policy_name, templ_type="initial-template", parent_dn="org-root"):

    # Args:
    # handle (UcsHandle)
    # name (String) : vNIC Template name

    from ucsmsdk.mometa.vnic.VnicSanConnTempl import VnicSanConnTempl
    from ucsmsdk.mometa.vnic.VnicFcIf import VnicFcIf

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError(parent_dn + " MO is not available")

    mo = VnicSanConnTempl(parent_mo_or_dn=obj, redundancy_pair_type="none",
                          name=name, descr=descr, stats_policy_name=stats_policy_name,
                          switch_id=fabric_id, pin_to_group_name=pin_to_group_name, policy_owner="local",
                          peer_redundancy_templ_name="", templ_type=templ_type,
                          qos_policy_name="", ident_pool_name=wwpn_pool, max_data_field_size="2048")

    mo_1 = VnicFcIf(parent_mo_or_dn=mo, name=vsan_name)

    handle.add_mo(mo)
    handle.commit()

    print "Created vHBA template " + name + " with wwpn pool "\
          + wwpn_pool + " in " + parent_dn

    return mo