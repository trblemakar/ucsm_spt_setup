__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_vnic_template(handle, parent_dn, name, vnic_dict):

    # Args:
    # handle (UcsHandle)
    # name (String) : vNIC Template name
    # vlans (List) : List of list - [[vlan_name, native_vlan:yes/no)],...]
    # con_policy_type (String) : Connection Policy Type ["dynamic-vnic","usnic","vmq"]
    # con_policy_name (String) : Connection Policy name
    # mtu (String)
    # qos_policy_name (String) : QoS Policy name
    # target (String) : ((vm|adaptor|defaultValue),){0,2} (vm|adaptor|defaultValue){0,1}
    # ident_pool_name (String) : MAC Address Pool name
    # nw_ctrl_policy_name (String) : Network Control Policy name
    # pin_to_group_name (String) : Pin Group name
    # switch_id (String) : ["A", "A-B", "B", "B-A", "NONE"]
    # stats_policy_name (String) : Stats Threshold Policy name
    # templ_type (String) : ["initial-template", "updating-template"]
    # descr (String) : description
    # parent_dn (String) : org dn

    from ucsmsdk.mometa.vnic.VnicLanConnTempl import VnicLanConnTempl
    from ucsmsdk.mometa.vnic.VnicDynamicConPolicyRef import VnicDynamicConPolicyRef
    from ucsmsdk.mometa.vnic.VnicUsnicConPolicyRef import VnicUsnicConPolicyRef
    from ucsmsdk.mometa.vnic.VnicVmqConPolicyRef import VnicVmqConPolicyRef
    from ucsmsdk.mometa.vnic.VnicEtherIf import VnicEtherIf

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError(parent_dn + " MO is not available")

    mo = VnicLanConnTempl(parent_mo_or_dn=obj,
                          templ_type=vnic_dict['templ_type'],
                          name=name,
                          descr=vnic_dict['descr'],
                          stats_policy_name=vnic_dict['stats_policy_name'],
                          switch_id=vnic_dict['switch_id'],
                          pin_to_group_name=vnic_dict['pin_to_group_name'],
                          mtu=vnic_dict['mtu'],
                          policy_owner=vnic_dict['policy_owner'],
                          qos_policy_name=vnic_dict['qos_policy_name'],
                          target=vnic_dict['target'],
                          ident_pool_name=vnic_dict['ident_pool_name'],
                          nw_ctrl_policy_name=vnic_dict['nw_ctrl_policy_name'])

    # TODO: Query to check if connection policy exists
    if vnic_dict['con_policy_name']:
        if vnic_dict['con_policy_type'].lower() == "dynamic-vnic":
            VnicDynamicConPolicyRef(parent_mo_or_dn=mo,
                                    con_policy_name=vnic_dict['con_policy_name'])
        elif vnic_dict['con_policy_type'].lower() == "usnic":
            VnicUsnicConPolicyRef(parent_mo_or_dn=mo,
                                  con_policy_name=vnic_dict['con_policy_name'])
        elif vnic_dict['con_policy_type'].lower() == "vmq":
            VnicVmqConPolicyRef(parent_mo_or_dn=mo,
                                con_policy_name=vnic_dict['con_policy_name'])
        else:
            raise ValueError(vnic_dict['con_policy_type'] + " is not a valid Connection Policy type.")

    vlan_mo = []
    if vnic_dict['vlan_list'] is not None:
        for vlan in vnic_dict['vlan_list']:
            vlan_name = vlan[0]
            is_native_vlan = vlan[1]
            vlan_mo.append(VnicEtherIf(parent_mo_or_dn=mo,
                                       name=vlan_name,
                                       default_net=is_native_vlan))

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created vNIC template: " + name, "with MAC pool " + vnic_dict['ident_pool_name'], "in " + parent_dn