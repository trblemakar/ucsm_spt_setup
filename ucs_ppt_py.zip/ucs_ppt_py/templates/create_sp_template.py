__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_sp_template(handle, parent_dn, sp_temp_dict):

    # Args:
    # handle (UcsHandle)
    # name (String): vNIC Template name
    # descr (String): description

    from ucsmsdk.mometa.ls.LsServer import LsServer
    from ucsmsdk.mometa.ls.LsVConAssign import LsVConAssign
    from ucsmsdk.mometa.vnic.VnicConnDef import VnicConnDef
    from ucsmsdk.mometa.vnic.VnicEther import VnicEther
    from ucsmsdk.mometa.vnic.VnicFc import VnicFc
    from ucsmsdk.mometa.vnic.VnicFcNode import VnicFcNode
    from ucsmsdk.mometa.ls.LsPower import LsPower
    from ucsmsdk.mometa.fabric.FabricVCon import FabricVCon

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError(parent_dn + " MO is not available")

    mo = LsServer(parent_mo_or_dn=obj,
                  vmedia_policy_name=sp_temp_dict['vmedia_policy_name'],
                  ext_ip_state=sp_temp_dict['ext_ip_state'],
                  bios_profile_name=sp_temp_dict['bios_profile_name'],
                  mgmt_fw_policy_name=sp_temp_dict['mgmt_fw_policy_name'],
                  agent_policy_name=sp_temp_dict['agent_policy_name'],
                  mgmt_access_policy_name=sp_temp_dict['mgmt_access_policy_name'],
                  dynamic_con_policy_name=sp_temp_dict['dynamic_con_policy_name'],
                  kvm_mgmt_policy_name=sp_temp_dict['kvm_mgmt_policy_name'],
                  sol_policy_name=sp_temp_dict['sol_policy_name'],
                  uuid=sp_temp_dict['uuid'],
                  descr=sp_temp_dict['descr'],
                  stats_policy_name=sp_temp_dict['stats_policy_name'],
                  policy_owner=sp_temp_dict['policy_owner'],
                  ext_ip_pool_name=sp_temp_dict['ext_ip_pool_name'],
                  boot_policy_name=sp_temp_dict['boot_policy_name'],
                  usr_lbl=sp_temp_dict['usr_lbl'],
                  host_fw_policy_name=sp_temp_dict['host_fw_policy_name'],
                  vcon_profile_name=sp_temp_dict['vcon_profile_name'],
                  ident_pool_name=sp_temp_dict['ident_pool_name'],
                  src_templ_name=sp_temp_dict['src_templ_name'],
                  type=sp_temp_dict['type'],
                  local_disk_policy_name=sp_temp_dict['local_disk_policy_name'],
                  scrub_policy_name=sp_temp_dict['scrub_policy_name'],
                  power_policy_name=sp_temp_dict['power_policy_name'],
                  maint_policy_name=sp_temp_dict['maint_policy_name'],
                  name=sp_temp_dict['name'],
                  power_sync_policy_name=sp_temp_dict['power_sync_policy_name'],
                  resolve_remote=sp_temp_dict['resolve_remote'])

#    mo_1 = LsVConAssign(parent_mo_or_dn=mo, admin_vcon="1", admin_host_port="ANY", order="3", transport="ethernet",
#                        vnic_name="eth0")

#    mo_2 = LsVConAssign(parent_mo_or_dn=mo, admin_vcon="1", admin_host_port="ANY", order="4", transport="ethernet",
#                        vnic_name="eth1")

#    mo_3 = LsVConAssign(parent_mo_or_dn=mo, admin_vcon="1", admin_host_port="ANY", order="1", transport="fc",
#                        vnic_name="fc0")

#    mo_4 = LsVConAssign(parent_mo_or_dn=mo, admin_vcon="1", admin_host_port="ANY", order="2", transport="fc",
#                        vnic_name="fc1")

    mo_5 = VnicConnDef(parent_mo_or_dn=mo, san_conn_policy_name=sp_temp_dict['san_conn_policy_name'],
                       lan_conn_policy_name=sp_temp_dict['lan_conn_policy_name'])

#    mo_6 = VnicEther(parent_mo_or_dn=mo, cdn_prop_in_sync="yes", nw_ctrl_policy_name="", admin_host_port="ANY",
#                     admin_vcon="1", stats_policy_name="default", admin_cdn_name="", switch_id="A",
#                     pin_to_group_name="", name="eth0", order="3", qos_policy_name="", adaptor_profile_name="",
#                     ident_pool_name="", cdn_source="vnic-name", mtu="1500", nw_templ_name="", addr="derived")

#    mo_7 = VnicEther(parent_mo_or_dn=mo, cdn_prop_in_sync="yes", nw_ctrl_policy_name="", admin_host_port="ANY",
#                     admin_vcon="1", stats_policy_name="default", admin_cdn_name="", switch_id="A",
#                     pin_to_group_name="", name="eth1", order="4", qos_policy_name="", adaptor_profile_name="",
#                     ident_pool_name="", cdn_source="vnic-name", mtu="1500", nw_templ_name="", addr="derived")

#    mo_8 = VnicFc(parent_mo_or_dn=mo, cdn_prop_in_sync="yes", addr="derived", admin_host_port="ANY", admin_vcon="1",
#                  stats_policy_name="default", admin_cdn_name="", switch_id="A", pin_to_group_name="",
#                  pers_bind="disabled", order="1", pers_bind_clear="no", qos_policy_name="", adaptor_profile_name="",
#                  ident_pool_name="", cdn_source="vnic-name", max_data_field_size="2048", nw_templ_name="", name="fc0")

#    mo_9 = VnicFc(parent_mo_or_dn=mo, cdn_prop_in_sync="yes", addr="derived", admin_host_port="ANY", admin_vcon="1",
#                  stats_policy_name="default", admin_cdn_name="", switch_id="A", pin_to_group_name="",
#                  pers_bind="disabled", order="2", pers_bind_clear="no", qos_policy_name="", adaptor_profile_name="",
#                  ident_pool_name="", cdn_source="vnic-name", max_data_field_size="2048", nw_templ_name="", name="fc1")

#    mo_10 = VnicFcNode(parent_mo_or_dn=mo, ident_pool_name="node-default", addr="pool-derived")

    mo_11 = LsPower(parent_mo_or_dn=mo, state=sp_temp_dict['server_power_state'])

#    mo_12 = FabricVCon(parent_mo_or_dn=mo, placement="physical", fabric="NONE", share="shared", select="all",
#                       transport="ethernet,fc", id="1", inst_type="manual")

#    mo_13 = FabricVCon(parent_mo_or_dn=mo, placement="physical", fabric="NONE", share="shared", select="all",
#                       transport="ethernet,fc", id="2", inst_type="manual")

#    mo_14 = FabricVCon(parent_mo_or_dn=mo, placement="physical", fabric="NONE", share="shared", select="all",
#                       transport="ethernet,fc", id="3", inst_type="manual")

#    mo_15 = FabricVCon(parent_mo_or_dn=mo, placement="physical", fabric="NONE", share="shared", select="all",
#                       transport="ethernet,fc", id="4", inst_type="manual")

    handle.add_mo(mo)
    handle.commit()

    print "Created Service Profile template: " + sp_temp_dict['name'] + " in " + parent_dn