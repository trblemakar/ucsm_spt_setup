__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def init_sp_temp_dict(sp_temp_name, sp_temp_descr):
    return {
        "name": sp_temp_name,
        "descr": sp_temp_descr,
        "vmedia_policy_name": "",
        "bios_profile_name": "",
        "mgmt_fw_policy_name": "",
        "agent_policy_name": "",
        "mgmt_access_policy_name": "",
        "dynamic_con_policy_name": "",
        "kvm_mgmt_policy_name": "",
        "sol_policy_name": "",
        "uuid": "0",
        "stats_policy_name": "default",
        "policy_owner": "local",
        "ext_ip_pool_name": "ext-mgmt",
        "ext_ip_state": "none",
        "boot_policy_name": "",
        "usr_lbl": "",
        "host_fw_policy_name": "",
        "vcon_profile_name": "",
        "ident_pool_name": "",
        "src_templ_name": "",
        "type": "updating-template",
        "local_disk_policy_name": "",
        "scrub_policy_name": "",
        "power_policy_name": "default",
        "maint_policy_name": "",
        "power_sync_policy_name": "",
        "resolve_remote": "yes",
        "lan_conn_policy_name": "",
        "san_conn_policy_name": "",
        "server_power_state": "admin-up"
    }