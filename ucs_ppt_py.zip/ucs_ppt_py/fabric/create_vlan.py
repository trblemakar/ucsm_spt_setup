__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_vlan(handle, vlans_dict):

    # Args:
    # handle (UcsHandle)
    # sharing (String) : ["community", "isolated", "none", "primary"]
    # vlan_name (String) : VLAN Name
    # vlan_id (String): VLAN ID
    # mcast_policy_name (String) : Multicast Policy Name
    # compression_type (string) : ["excluded", "included"]
    # default_net (String) : ["false", "no", "true", "yes"]
    # pub_nw_name (String) :
    # vlan_dn (String) :

    from ucsmsdk.mometa.fabric.FabricVlan import FabricVlan

    for vlan_name in vlans_dict:
        obj = handle.query_dn(vlans_dict[vlan_name]['vlan_dn'])

        if not obj:
            raise ValueError("LAN '%s' is not available" % vlans_dict[vlan_name]['vlan_dn'])

        mo = FabricVlan(parent_mo_or_dn=obj,
                        sharing=vlans_dict[vlan_name]['sharing'],
                        name=vlan_name,
                        id=vlans_dict[vlan_name]['vlan_id'],
                        mcast_policy_name=vlans_dict[vlan_name]['mcast_policy_name'],
                        policy_owner=vlans_dict[vlan_name]['policy_owner'],
                        default_net=vlans_dict[vlan_name]['default_net'],
                        pub_nw_name=vlans_dict[vlan_name]['pub_nw_name'],
                        compression_type=vlans_dict[vlan_name]['compression_type'])

        handle.add_mo(mo, modify_present=True)
        handle.commit()

        print "Created VLAN: " + vlan_name, "in " + vlans_dict[vlan_name]['vlan_dn']