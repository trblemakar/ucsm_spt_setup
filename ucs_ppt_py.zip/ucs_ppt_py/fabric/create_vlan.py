__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

import logging

log = logging.getLogger("ucs")

def create_vlan(handle, vlan_name, vlan_id, sharing="none",
                mcast_policy_name="", compression_type="included",
                default_net="no", pub_nw_name="", parent_dn="fabric/lan"):

    # Args:
    # handle (UcsHandle)
    # sharing (String) : ["community", "isolated", "none", "primary"]
    # vlan_name (String) : VLAN Name
    # vlan_id (String): VLAN ID
    # mcast_policy_name (String) : Multicast Policy Name
    # compression_type (string) : ["excluded", "included"]
    # default_net (String) : ["false", "no", "true", "yes"]
    # pub_nw_name (String) :
    # parent_dn (String) :

    from ucsmsdk.mometa.fabric.FabricVlan import FabricVlan

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("lan '%s' is not available" % parent_dn)

    mo = FabricVlan(parent_mo_or_dn=obj,
                    sharing=sharing,
                    name=vlan_name,
                    id=vlan_id,
                    mcast_policy_name=mcast_policy_name,
                    policy_owner="local",
                    default_net=default_net,
                    pub_nw_name=pub_nw_name,
                    compression_type=compression_type)

    handle.add_mo(mo, modify_present=True)
    handle.commit()

    print "Created VLAN: " + vlan_name, "in " + parent_dn

    return mo