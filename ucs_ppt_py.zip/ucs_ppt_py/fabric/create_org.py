__author__ = 'jamakar'

# Requires the UCS Python SDK v0.9

def create_org(handle, parent_dn, name, descr):

    from ucsmsdk.mometa.org.OrgOrg import OrgOrg

    obj = handle.query_dn(parent_dn)

    if not obj:
        raise ValueError("org '%s' is not available" % parent_dn)

    mo = OrgOrg(parent_mo_or_dn=obj, name=name, descr=descr)

    handle.add_mo(mo)
    handle.commit()

    print "Created Org: " + name, "in " + parent_dn

    return mo